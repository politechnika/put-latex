package com.dawidweiss.jedit.macros;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.logging.Logger;

import org.junit.Test;

public class FormatLatexTableTest {
	private static Logger logger = Logger.getAnonymousLogger();

	@Test
	public void parseTabular() throws Exception {
		logger.info("\n" + FormatLatexTable.process(readResource("tabular.txt")));
	}

	@Test
	public void parseTabularx() throws Exception {
		logger.info("\n" + FormatLatexTable.process(readResource("tabularx.txt")));
	}
	
	@Test
	public void parseMulticolumn() throws Exception {
		logger.info("\n" + FormatLatexTable.process(readResource("multicol.txt")));
	}

	private String readResource(String res) throws IOException {
		final Reader r = new InputStreamReader(
				FormatLatexTableTest.class.getResourceAsStream(res),
				"UTF-8");
		
		final StringWriter sw = new StringWriter();

		int chr;
		while ((chr = r.read()) != -1) {
			sw.write(chr);
		}
		
		String content = sw.toString();
		return content;
	}
}
